"""Calculated, fictitious examples that explain the module without refitting it."""
from pathlib import Path
import base64
import json
import math

HERE = Path(__file__).resolve().parent
FIGURES = HERE / 'figuras'

WEIGHTED_TEXT = '''
### Primero, hagamos una cuenta pequeña

![Cuatro entradas ficticias multiplicadas por sus pesos; los productos suman 0.80, el término independiente resta 0.30 y la sigmoide convierte z=0.50 en 0.622.](attachment:suma_cuatro_entradas.png)

**Estos cuatro valores y pesos son inventados para aprender la cuenta.** No proceden de radiografías ni de un entrenamiento. En el modelo del taller habrá 784 entradas; el procedimiento de sumar será el mismo.

1. **Lee las entradas:** `x = [0.20, 0.80, 0.60, 0.40]`. Imagina una imagen diminuta de 2 × 2 convertida en una fila, conservando su orden.
2. **Multiplica posición por posición** con `w = [1.00, -1.00, 2.00, 0.50]`. Los productos son `[0.20, -0.80, 1.20, 0.20]`. Un peso negativo aporta una resta; los pesos no están limitados al intervalo 0–1.
3. **Suma los cuatro productos:** `0.20 - 0.80 + 1.20 + 0.20 = 0.80`. Añade el término independiente, `b = -0.30`: queda `z = 0.50`. Ese término desplaza la suma y no multiplica ningún píxel.
4. **Transforma y decide:** `1 / (1 + exp(-0.50)) ≈ 0.622`. Con el umbral 0.5, la regla asigna clase 1. La puntuación y la clase son dos cosas diferentes.

```python
# Cuenta ilustrativa; no cambia el modelo del taller.
x_ejemplo = np.array([0.20, 0.80, 0.60, 0.40])
w_ejemplo = np.array([1.00, -1.00, 2.00, 0.50])
productos_ejemplo = x_ejemplo * w_ejemplo
z_ejemplo = productos_ejemplo.sum() - 0.30
s_ejemplo = 1 / (1 + np.exp(-z_ejemplo))
# Salida: productos [0.20, -0.80, 1.20, 0.20]; z=0.50; s≈0.622.
```

El símbolo `*` multiplica las posiciones correspondientes de los dos arreglos; `.sum()` reúne sus contribuciones. **Predecir** reutiliza pesos y término independiente. **Aprender** busca esos números a partir de las imágenes y etiquetas de entrenamiento: la celda 6 hará ese ajuste. Aquí elegimos números a mano únicamente para que puedas comprobar la operación.

**Antes de seguir:** si la tercera entrada baja de 0.60 a 0.10 y los pesos siguen iguales, ¿qué sucede?

<details><summary>Ver solución del ejemplo pequeño</summary>

Su contribución baja de `2 × 0.60 = 1.20` a `2 × 0.10 = 0.20`. La suma final cambia de `z=0.50` a `z=-0.50`; la puntuación es aproximadamente 0.378 y la decisión pasa a clase 0. Hemos cambiado una entrada, no entrenado otros pesos. Es un cálculo ficticio, no evidencia sobre una región anatómica.

</details>

Ahora la celda de código dibuja la sigmoide para muchos valores de `z`, incluyendo puntos negativos y positivos.
'''

CONFUSION_TEXT = '''
### Antes de comparar umbrales: de cuatro casos a cuatro casillas

![Cuatro casos ficticios A, B, C y D se clasifican con umbral 0.5: A va a verdadero negativo, B a falso positivo, C a falso negativo y D a verdadero positivo. Las filas son referencia y las columnas predicción.](attachment:cuatro_casos_confusion.png)

Las puntuaciones y etiquetas de esta figura son **inventadas**. No son cuatro pacientes, resultados de validación ni una nueva evaluación del modelo. Sirven para aprender cómo se cuentan los resultados.

1. **Convierte cada puntuación en una predicción:** si es al menos 0.5, escribe 1; en caso contrario, escribe 0. Para A, B, C y D obtenemos `[0, 1, 0, 1]`.
2. **Busca la fila de la referencia** publicada para el caso: `[0, 0, 1, 1]`. La referencia se usa para evaluar, no se entrega al modelo al predecir.
3. **Busca la columna de la predicción.** Su cruce es la casilla que recibe un conteo. A: fila 0, columna 0 → VN; B: fila 0, columna 1 → FP; C: fila 1, columna 0 → FN; D: fila 1, columna 1 → VP.
4. **Suma los conteos:** hay uno en cada casilla; `1 + 1 + 1 + 1 = 4`. La diagonal contiene dos coincidencias y las otras dos casillas contienen discrepancias.

**Negativo** significa predicción 0 y **positivo**, predicción 1. **Verdadero** significa que esa predicción coincide con la referencia; **falso**, que no coincide. Por ejemplo, un falso negativo es una predicción 0 cuya referencia era 1. Estos nombres no juzgan la gravedad de una imagen.

```python
# Ejemplo ficticio; distinto de los conjuntos del taller.
y_ejemplo = np.array([0, 0, 1, 1])
s_ejemplo = np.array([0.20, 0.80, 0.30, 0.70])
pred_ejemplo = (s_ejemplo >= 0.5).astype(int)
confusion_matrix(y_ejemplo, pred_ejemplo, labels=[0, 1])
# Salida por filas: [[1, 1], [1, 1]]
```

**Predice antes de mirar la solución:** si bajamos el umbral a 0.3, ¿qué caso cambia de casilla? Recuerda que usamos `>=`, que incluye la igualdad.

<details><summary>Ver solución del cambio de umbral</summary>

C tiene puntuación 0.30: ahora su predicción es 1. Conserva referencia 1 y pasa de FN a VP. A sigue en VN, B en FP y D en VP. La matriz queda `[[1, 1], [0, 2]]`; sigue contando cuatro casos. No cambian las puntuaciones ni se vuelve a entrenar.

</details>

Ahora leeremos las tres matrices de **validación real del taller** con el mismo orden de ejes. Sus conteos serán mayores porque resumen 516 imágenes, no los cuatro casos ficticios.
'''

def generate_figures():
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch

    FIGURES.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':12,
                         'text.color':'#102c40', 'figure.facecolor':'white'})
    ink, teal, coral, pale = '#102c40', '#007f89', '#b34e32', '#eaf4f4'
    x = np.array([.2,.8,.6,.4]); w = np.array([1.,-1.,2.,.5]); b = -.3
    products = x*w; z = float(products.sum()+b); score = 1/(1+math.exp(-z))
    assert np.allclose(products,[.2,-.8,1.2,.2]) and math.isclose(z,.5)
    assert math.isclose(score,0.6224593312018546)
    fig, ax = plt.subplots(figsize=(11.5,5.9)); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis('off')
    ax.text(.02,.96,'De cuatro entradas a una puntuación',fontsize=21,weight='bold',va='top')
    ax.text(.02,.85,'Ejemplo ficticio: los pesos están elegidos a mano.',color='#526674',fontsize=12)
    headers=[('Posición',.08),('Entrada x',.27),('Peso w',.48),('Producto x × w',.75)]
    for label,pos in headers: ax.text(pos,.79,label,ha='center',weight='bold',color=teal)
    for i,(xi,wi,prod) in enumerate(zip(x,w,products)):
        y=.68-i*.105
        ax.add_patch(FancyBboxPatch((.02,y-.043),.94,.082,boxstyle='round,pad=.004',facecolor=pale if i%2==0 else '#f8fafb',edgecolor='none'))
        for value,pos,color in [(str(i+1),.08,ink),(f'{xi:.2f}',.27,ink),(f'{wi:.2f}',.48,coral if wi<0 else ink),(f'{prod:.2f}',.75,coral if prod<0 else ink)]:
            ax.text(pos,y,value,ha='center',va='center',fontsize=16,color=color)
        ax.text(.365,y,'×',ha='center',va='center',fontsize=16,color='#526674')
        ax.text(.595,y,'=',ha='center',va='center',fontsize=16,color='#526674')
    ax.text(.03,.235,'SUMAR PRODUCTOS',fontsize=10,color=teal,weight='bold')
    ax.text(.03,.175,'0.20 − 0.80 + 1.20 + 0.20 = 0.80',fontsize=14)
    ax.text(.03,.095,'Añadir b = −0.30  →  z = 0.50',fontsize=14,weight='bold')
    ax.add_patch(FancyBboxPatch((.61,.045),.34,.205,boxstyle='round,pad=.013',facecolor=ink,edgecolor='none'))
    ax.text(.78,.205,'SIGMOIDE → DECISIÓN',color='white',fontsize=10,ha='center',weight='bold')
    ax.text(.78,.145,f's = {score:.3f}',color='white',fontsize=21,ha='center',weight='bold')
    ax.text(.78,.078,'0.622 ≥ 0.5 → clase 1',color='white',fontsize=12,ha='center')
    fig.savefig(FIGURES/'suma_cuatro_entradas.png',dpi=180,bbox_inches='tight',pad_inches=.15);plt.close(fig)

    scores=np.array([.2,.8,.3,.7]); refs=np.array([0,0,1,1]); pred=(scores>=.5).astype(int)
    matrix=np.zeros((2,2),dtype=int)
    for r,p in zip(refs,pred):matrix[r,p]+=1
    assert matrix.tolist()==[[1,1],[1,1]]
    fig,ax=plt.subplots(figsize=(11.5,6.5));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    ax.text(.02,.965,'Cada caso ocupa una sola casilla',fontsize=21,weight='bold',va='top')
    ax.text(.02,.855,'Cuatro casos ficticios · umbral 0.5 · filas = referencia · columnas = predicción',fontsize=11.5,color='#526674')
    ax.text(.02,.81,'1  LEER Y DECIDIR',fontsize=11,color=teal,weight='bold')
    labels=['VN','FP','FN','VP']; colors=[teal,coral,coral,teal]
    for i,(s,r,p,label,color) in enumerate(zip(scores,refs,pred,labels,colors)):
        y=.69-i*.15; case='ABCD'[i]
        ax.add_patch(FancyBboxPatch((.02,y-.055),.43,.11,boxstyle='round,pad=.008',facecolor='#eaf4f4' if label in ['VN','VP'] else '#fff1ec',edgecolor='none'))
        ax.text(.04,y+.022,f'{case}   puntuación {s:.2f} → predicción {p}',fontsize=12,weight='bold',va='center')
        ax.text(.04,y-.025,f'Referencia {r} → {label}',fontsize=11,color=color,va='center')
    ax.text(.56,.81,'2  FILA + COLUMNA → CONTEO',fontsize=11,color=teal,weight='bold')
    ax.text(.765,.735,'PREDICCIÓN',fontsize=10,weight='bold',ha='center')
    ax.text(.66,.69,'0',ha='center',fontsize=14);ax.text(.87,.69,'1',ha='center',fontsize=14)
    ax.text(.49,.435,'REFERENCIA',fontsize=10,weight='bold',ha='center',rotation=90)
    positions=[(.56,.44),(.77,.44),(.56,.20),(.77,.20)]
    names=['Verdadero negativo','Falso positivo','Falso negativo','Verdadero positivo']
    for i,((left,bottom),label,name,color) in enumerate(zip(positions,labels,names,colors)):
        ax.add_patch(FancyBboxPatch((left,bottom),.19,.21,boxstyle='round,pad=.006',facecolor=pale if i in [0,3] else '#fff1ec',edgecolor=color,linewidth=1.3))
        ax.text(left+.095,bottom+.16,f'{label}  ·  caso {"ABCD"[i]}',ha='center',fontsize=12,weight='bold',color=color)
        ax.text(left+.095,bottom+.105,'1',ha='center',fontsize=26,weight='bold',va='center')
        ax.text(left+.095,bottom+.032,name.replace(' ','\n',1),ha='center',va='center',fontsize=9.5)
    ax.text(.53,.545,'0',ha='center',fontsize=14);ax.text(.53,.305,'1',ha='center',fontsize=14)
    ax.text(.02,.065,'3  COMPROBAR: 1 + 1 + 1 + 1 = 4 casos; 2 coincidencias y 2 discrepancias.',fontsize=12,weight='bold')
    fig.savefig(FIGURES/'cuatro_casos_confusion.png',dpi=180,bbox_inches='tight',pad_inches=.15);plt.close(fig)
    report={'synthetic':True,'inputs':x.tolist(),'weights':w.tolist(),'products':products.tolist(),'bias':b,'z':z,'score':score,'prediction':int(score>=.5),'confusion_cases':{'reference':refs.tolist(),'scores':scores.tolist(),'prediction':pred.tolist(),'matrix':matrix.tolist()}}
    (HERE/'pedagogia_visual_calculos.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report

def attach_examples(nb, lessons):
    for number, text, filename in [(4,WEIGHTED_TEXT,'suma_cuatro_entradas.png'),(8,CONFUSION_TEXT,'cuatro_casos_confusion.png')]:
        cell=next(c for c in nb['cells'] if c['cell_type']=='markdown' and str(c['source']).startswith(f'## Celda {number:02} ·'))
        source=cell['source']
        if number==8:
            # Teach the four-case count before the existing three-threshold exploration.
            heading, original=source.split('\n\n',1)
            cell['source']=heading+'\n\n'+text.strip()+'\n\n'+original
        else:cell['source']=source.rstrip()+'\n\n'+text.strip()+'\n'
        cell['attachments']={filename:{'image/png':base64.b64encode((FIGURES/filename).read_bytes()).decode('ascii')}}
        lessons[number-1]['before']=cell['source'].split('\n\n',1)[1]

if __name__=='__main__':
    print(json.dumps(generate_figures(),ensure_ascii=False,indent=2))
