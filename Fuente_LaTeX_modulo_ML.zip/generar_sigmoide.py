from pathlib import Path
import sys, os
HERE=Path(__file__).resolve().parent
local_packages=HERE.parents[2]/'.work/python_packages'
if local_packages.is_dir():
    sys.path.insert(0,str(local_packages))
os.environ['MPLBACKEND']='Agg'
os.environ['MPLCONFIGDIR']=str(HERE/'mplconfig')
import numpy as np
import matplotlib.pyplot as plt
(HERE/'figuras').mkdir(exist_ok=True)
z=np.linspace(-6,6,301)
s=1/(1+np.exp(-z))
fig,ax=plt.subplots(figsize=(10.5,2.8),layout='constrained')
ax.plot(z,s,color='#007f86',linewidth=2.4)
ax.axhline(.5,color='#c96932',linestyle='--',linewidth=1.3)
ax.axvline(0,color='#526674',linestyle=':',linewidth=1)
for zi,xy in [(-2,(-3.7,.22)),(0,(.5,.40)),(2,(2.5,.76))]:
    si=1/(1+np.exp(-zi));ax.plot(zi,si,'o',color='#102c45')
    ax.annotate(f'z = {zi}:  s = {si:.3f}',(zi,si),xytext=xy,fontsize=12,color='#102c45',arrowprops={'arrowstyle':'-','color':'#526674','lw':.8})
ax.set(xlim=(-6,6),ylim=(-.03,1.03),xlabel='Puntaje z: suma ponderada de entradas y término independiente',ylabel='Salida s')
ax.tick_params(labelsize=11)
ax.xaxis.label.set_fontsize(12);ax.yaxis.label.set_fontsize(12)
ax.spines[['top','right']].set_visible(False)
fig.savefig(HERE/'figuras/sigmoide_manual.png',dpi=190,bbox_inches='tight',facecolor='white')
