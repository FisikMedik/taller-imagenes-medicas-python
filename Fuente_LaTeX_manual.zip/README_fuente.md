# Fuente editable de la guía visual

Esta carpeta contiene la fuente de **Guía visual de imágenes médicas con Python**, su estilo y las ilustraciones utilizadas. Las figuras ya están incluidas: **no hace falta Python para obtener el PDF**.

El manual conserva conceptos ilustrados, ejemplos de código y tutoriales de consulta con numeración propia. Sus números no corresponden a los del cuaderno unificado. Las figuras incluidas permiten compilar el PDF sin ejecutar Python.

## Compilar en Overleaf

1. Crea un proyecto nuevo y elige **Subir proyecto** para cargar el ZIP de la fuente.
2. Abre la configuración del proyecto y selecciona **XeLaTeX** como compilador.
3. Selecciona **Guia_visual_imagenes_medicas.tex** como documento principal.
4. Compila. Vuelve a compilar para actualizar el índice, las referencias y la numeración si fuera necesario.

Conserva juntos `Guia_visual_imagenes_medicas.tex`, `estilo.tex`, `portada.png` y las carpetas `figuras` y `fonts`. Mantén los nombres y la estructura de carpetas al editar o trasladar el proyecto. Los archivos de la carpeta `datos` y el generador de Python sirven para reproducir las ilustraciones; la compilación de LaTeX no los necesita. Las fuentes de código DejaVu Sans Mono se incluyen con su licencia para conservar letras, acentos y símbolos. TeX Gyre Pagella y Heros se obtienen de la distribución de LaTeX.

## Compilar en tu equipo

Necesitas una distribución de LaTeX que incluya XeLaTeX y los paquetes utilizados en `estilo.tex`. Abre una terminal en esta carpeta y ejecuta dos pasadas:

```text
xelatex -interaction=nonstopmode -halt-on-error Guia_visual_imagenes_medicas.tex
xelatex -interaction=nonstopmode -halt-on-error Guia_visual_imagenes_medicas.tex
```

El resultado es `Guia_visual_imagenes_medicas.pdf`. Las dos pasadas permiten resolver el índice y las referencias internas. La portada y las figuras deben permanecer en sus rutas originales para que LaTeX las encuentre.

## Regenerar las figuras, de forma opcional

El archivo `reproducir_figuras.py` genera 20 ilustraciones científicas con NumPy, Matplotlib, SciPy y NiBabel. Lee `datos/mni152_2mm.nii.gz`; no descarga datos ni requiere Nilearn. Los ejemplos ficticios se calculan en el propio programa y el ruido utiliza la semilla 2026. Las demás figuras están incluidas y documentan los ejemplos impresos del manual. El cuaderno actual del repositorio es `Taller_imagenes_medicas.ipynb`; no es necesario ejecutarlo para compilar este libro ni se presupone que reproduzca su numeración.

Las versiones utilizadas para la revisión están fijadas en `requirements_figuras.txt`. Se trabajó con Python 3.12.14. En Windows, desde esta carpeta, puedes crear un entorno independiente y generar una copia de las figuras:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements_figuras.txt
.\.venv\Scripts\python.exe reproducir_figuras.py --salida figuras_regeneradas
```

En macOS o Linux, el equivalente es:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements_figuras.txt
.venv/bin/python reproducir_figuras.py --salida figuras_regeneradas
```

Para regenerar directamente la carpeta que utiliza el documento, ejecuta el programa sin `--salida`, con el mismo intérprete del entorno anterior. Esto reemplaza los PNG de igual nombre dentro de `figuras`. Revisa los resultados y vuelve a compilar el PDF. Por ejemplo, en Windows:

```powershell
.\.venv\Scripts\python.exe reproducir_figuras.py
```

Las opciones disponibles son:

- `--datos`: ruta del NIfTI de entrada. El valor predeterminado es `datos/mni152_2mm.nii.gz`.
- `--salida`: carpeta que recibirá los 20 PNG y `figures_manifest.json`. El valor predeterminado es `figuras`.
- `--help`: muestra la ayuda sin cargar las bibliotecas científicas ni generar imágenes.

Las rutas relativas se interpretan **respecto a la carpeta del programa**, aunque lo ejecutes desde otra ubicación. También se admiten rutas absolutas. El manifiesto se escribe dentro de la carpeta elegida para la salida; sus nombres de PNG son relativos a esa misma carpeta. Registra los parámetros, las descripciones y las huellas SHA256 para comprobar los archivos.

El generador está preparado para la plantilla incluida: rejilla RAS de 2 mm y cortes concretos. Cambiar `--datos` permite trasladar una copia de ese archivo; otro volumen puede requerir adaptar el código, sus índices y las leyendas. Las comprobaciones de geometría evitan tratar cualquier archivo como si fuera la misma plantilla.

## Datos, procedencia y licencia

El NIfTI incluido es una **plantilla T1 MNI152 distribuida por Nilearn 0.12.1**, preparada aquí con espaciado de 2 mm. Es una referencia agregada de uso docente, no el estudio de un paciente de este taller. Las etiquetas de regiones, siluetas y personas usadas en los diagramas son ejemplos ficticios.

La huella SHA256 del NIfTI incluido es:

```text
a5f0ddb2d173ffb7b34a511fa6bcfe71e27218a54125092917a6d9630bc4513a
```

Consulta `FUENTES_Y_LICENCIAS.txt` para la atribución, las referencias y el texto íntegro de la licencia del recurso de origen. Conserva ese archivo al redistribuir la fuente o los datos. La portada es una ilustración editorial; el programa de Python reproduce las figuras científicas, no la portada.
