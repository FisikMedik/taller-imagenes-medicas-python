"""Figuras científicas reproducibles para la guía de imágenes médicas.

Ejecutar con Python 3.12 y las dependencias de requirements_figuras.txt.
Carga el NIfTI local directamente. No importa ni descarga Nilearn.
Las rutas relativas de --datos y --salida se resuelven junto a este script.
Cada ejecución guarda 20 PNG y figures_manifest.json en --salida.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(
    description='Regenera las 20 figuras científicas de la guía a partir del NIfTI incluido.',
    epilog='Las rutas relativas se resuelven respecto a la carpeta de este script.',
)
parser.add_argument('--datos', type=Path, default=Path('datos/mni152_2mm.nii.gz'),
                    help='NIfTI de entrada (por defecto: datos/mni152_2mm.nii.gz).')
parser.add_argument('--salida', type=Path, default=Path('figuras'),
                    help='Carpeta de PNG y manifiesto (por defecto: figuras).')
args = parser.parse_args()


def resolve_script_path(path):
    return (path if path.is_absolute() else BASE / path).resolve()


NIFTI = resolve_script_path(args.datos)
OUT = resolve_script_path(args.salida)
if not NIFTI.is_file():
    parser.error(f'No se encontró el NIfTI: {NIFTI}')
try:
    NIFTI_REFERENCE = os.path.relpath(NIFTI, OUT).replace(os.sep, '/')
except ValueError:
    # Windows no permite una ruta relativa entre unidades diferentes.
    NIFTI_REFERENCE = NIFTI.as_posix()

import numpy as np
import nibabel as nib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
from matplotlib.patches import Circle, Rectangle, FancyBboxPatch
from matplotlib.lines import Line2D
from scipy import ndimage

NAVY = '#102C45'
TEAL = '#007F86'
AMBER = '#E8AD54'
CORAL = '#D96557'
GREY = '#5A6772'
LIGHT = '#E4ECEF'
SEED = 2026
DPI = 220
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 12,
    'axes.titlesize': 13, 'axes.labelsize': 12,
    'xtick.labelsize': 12, 'ytick.labelsize': 12,
    'legend.fontsize': 12, 'figure.titlesize': 14,
    'text.color': NAVY, 'axes.labelcolor': NAVY,
    'xtick.color': GREY, 'ytick.color': GREY,
    'axes.edgecolor': GREY, 'axes.spines.top': False,
    'axes.spines.right': False, 'figure.facecolor': 'white',
    'savefig.facecolor': 'white', 'axes.facecolor': 'white',
    'axes.titlepad': 10, 'axes.labelpad': 6,
    'figure.constrained_layout.use': True,
})

IM = nib.load(NIFTI)
DATA = IM.get_fdata(dtype=np.float32)
AFFINE = IM.affine
SPACING = np.asarray(IM.header.get_zooms()[:3], dtype=float)
assert nib.aff2axcodes(AFFINE) == ('R', 'A', 'S')
assert np.allclose(AFFINE[:3, :3], np.diag(SPACING))
assert np.allclose(SPACING, [2, 2, 2])
X = AFFINE[0, 3] + SPACING[0] * np.arange(DATA.shape[0])
Y = AFFINE[1, 3] + SPACING[1] * np.arange(DATA.shape[1])
Z = AFFINE[2, 3] + SPACING[2] * np.arange(DATA.shape[2])
K = 46
CUT = DATA[:, :, K].T.astype(float)
EXTENT = [X[0]-1, X[-1]+1, Y[0]-1, Y[-1]+1]
SUPPORT = CUT > 1e-6
TOY = np.array([[0,0,0,0,0,0], [0,1,1,2,2,0],
                [0,1,3,4,2,0], [0,1,3,5,2,0],
                [0,1,1,2,2,0], [0,0,0,0,0,0]])
assert np.array_equal(np.bincount(TOY.ravel()), [20,6,6,2,1,1])
NIFTI_SHA = hashlib.sha256(NIFTI.read_bytes()).hexdigest()
MANIFEST = []
CMAP = LinearSegmentedColormap.from_list('navy_teal', ['white', TEAL, NAVY])


def save(fig, fid, caption, parameters, kind='matemático sintético'):
    path = OUT / f'{fid}.png'
    fig.savefig(path, dpi=DPI, bbox_inches=None)
    if kind == 'plantilla pública':
        provenance = {
            'tipo': kind,
            'fuente': 'Plantilla T1 MNI152 distribuida por Nilearn 0.12.1; copia NIfTI local de 2 mm.',
            'archivo_fuente': NIFTI_REFERENCE,
            'sha256_fuente': NIFTI_SHA,
            'lectura': 'NiBabel; sin importar Nilearn ni descargar datos.',
            'url': 'https://www.bic.mni.mcgill.ca/ServicesAtlases/ICBM152NLin2009',
            'nota': 'Referencia agregada; no es un estudio individual ni un conjunto de pacientes.',
        }
    else:
        provenance = {
            'tipo': kind,
            'fuente': 'Ejemplo original generado matemáticamente por este script.',
            'nota': 'Figuras, identidades y etiquetas ficticias; sin datos de pacientes.',
        }
    MANIFEST.append({
        'id': fid, 'archivo': path.name,
        'caption': caption, 'numparametros': parameters,
        'provenance': provenance,
        'tamano_pulgadas': list(map(float, fig.get_size_inches())),
        'dpi': DPI, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    })
    plt.close(fig)
    print(fid, flush=True)


def brain(ax, array=CUT, title='', ticks=True, vmin=0, vmax=1, cmap='gray'):
    artist = ax.imshow(array, origin='lower', extent=EXTENT, cmap=cmap,
                       vmin=vmin, vmax=vmax, interpolation='nearest')
    ax.set_title(title)
    ax.set_xlim(-78, 78)
    ax.set_ylim(-110, 84)
    if ticks:
        ax.set(xticks=[-50, 0, 50], yticks=[-100, -50, 0, 50],
               xlabel='x (mm) · L → R', ylabel='y (mm) · P → A')
    else:
        ax.set(xticks=[], yticks=[])
    return artist


def box(ax, xy, width, height, text, edge=TEAL, face='white', fontsize=12):
    rect = FancyBboxPatch(xy, width, height,
                          boxstyle='round,pad=0.02,rounding_size=0.04',
                          linewidth=1.5, edgecolor=edge, facecolor=face)
    ax.add_patch(rect)
    ax.text(xy[0]+width/2, xy[1]+height/2, text, ha='center', va='center',
            fontsize=fontsize, linespacing=1.45)
    return rect


def arrow(ax, start, end, color=GREY):
    ax.annotate('', xy=end, xytext=start,
                arrowprops={'arrowstyle': '->', 'color': color, 'lw': 1.6})


# 01: el registro se ilustra sólo mediante traslaciones conocidas de siluetas.
q = np.linspace(-1.7, 1.7, 180)
xx, yy = np.meshgrid(q, q)
offsets = [(-.42, .17), (.3, -.23), (.05, .31)]
silhouettes, aligned = [], []
for n, (dx, dy) in enumerate(offsets):
    a, b = 0.82 + n*.035, 1.04 - n*.025
    def silhouette(u, v):
        return (((u/a)**2 + (v/b)**2 < 1) &
                ~((np.abs(u) < .11) & (v > .15))).astype(float)
    silhouettes.append(silhouette(xx-dx, yy-dy))
    aligned.append(silhouette(xx, yy))
fig, axes = plt.subplots(1, 3, figsize=(6.7, 3.45))
for arr, color in zip(silhouettes, [TEAL, CORAL, AMBER]):
    axes[0].contour(xx, yy, arr, levels=[.5], colors=[color], linewidths=1.4)
for arr, color in zip(aligned, [TEAL, CORAL, AMBER]):
    axes[1].contour(xx, yy, arr, levels=[.5], colors=[color], linewidths=1.4)
avg = np.mean(aligned, axis=0)
axes[2].imshow(avg, origin='lower', extent=[-1.7,1.7,-1.7,1.7], cmap=CMAP, vmin=0, vmax=1)
for ax, title in zip(axes, ['Sin alinear', 'Centros alineados', 'Promedio']):
    ax.set_title(title); ax.set_aspect('equal'); ax.set(xticks=[], yticks=[])
fig.suptitle('Alinear antes de promediar · siluetas ficticias')
save(fig, '01_registro_promedio',
     'Tres siluetas ficticias se trasladan a un centro común antes de promediarlas. El color final resume su coincidencia. Es una ilustración del principio de registro, no una reproducción del algoritmo usado para construir MNI152.',
     {'numero_siluetas': 3, 'traslaciones_sinteticas': offsets, 'promedio': 'media aritmética de máscaras alineadas'})

# 02: la plantilla real se contrasta con etiquetas puramente geométricas.
fig, axes = plt.subplots(1, 2, figsize=(6.7, 4.35))
brain(axes[0], title='Plantilla anatómica\nintensidades continuas', ticks=False)
u, v = np.meshgrid(np.linspace(-1,1,120), np.linspace(-1.2,1.2,140))
inside = u*u/.82**2 + v*v/1.08**2 < 1
labels = np.zeros_like(u, dtype=int)
labels[inside & (u < -.1)] = 1
labels[inside & (u >= -.1) & (v >= -.15)] = 2
labels[inside & (u >= -.1) & (v < -.15)] = 3
axes[1].imshow(labels, origin='lower', cmap=ListedColormap(['white', TEAL, AMBER, CORAL]), vmin=0, vmax=3)
axes[1].set(title='Mapa de etiquetas\nregiones ficticias', xticks=[], yticks=[])
handles = [Rectangle((0,0),1,1,color=c,label=n) for c,n in zip([TEAL,AMBER,CORAL],['A','B','C'])]
axes[1].legend(handles=handles, loc='lower center', bbox_to_anchor=(.5,-.16), ncol=3, frameon=False,
               columnspacing=.7, handlelength=.8)
save(fig, '02_plantilla_etiquetas',
     'Una plantilla anatómica ofrece intensidades; un mapa de etiquetas asigna categorías a regiones. A la izquierda se muestra la plantilla pública. A la derecha, las regiones A, B y C son dibujos geométricos ficticios, no un atlas anatómico real ni una segmentación del cerebro mostrado.',
     {'corte_axial_k': K, 'z_mm': float(Z[K]), 'etiquetas_ficticias': ['A','B','C']}, 'plantilla pública')

# 03: vóxel con dimensiones físicas y una selección bidimensional.
fig = plt.figure(figsize=(6.7, 4.15))
ax = fig.add_subplot(121, projection='3d')
filled = np.ones((3,3,3), dtype=bool)
colors = np.empty(filled.shape, dtype=object)
colors[:] = '#007F8620'; colors[2,0,0] = AMBER
ax.voxels(filled, facecolors=colors, edgecolor='#102C4570', linewidth=.7)
ax.set_axis_off()
ax.set_title('Rejilla de vóxeles')
ax.view_init(22, -54); ax.set_box_aspect((1,1,1))
ay = fig.add_subplot(122)
small=np.array([[1,2,3],[4,5,6],[7,8,9]])
ay.imshow(small,cmap=CMAP,vmin=0,vmax=9,interpolation='nearest')
for (r,c), value in np.ndenumerate(small):
    ay.text(c,r,str(value),ha='center',va='center',color='white' if value>5 else NAVY,fontsize=14)
ay.set(title='Matriz de un corte', xlabel='Columna', ylabel='Fila',xticks=[0,1,2],yticks=[0,1,2])
fig.supxlabel('Un vóxel de 2 × 2 × 2 mm ocupa 8 mm³',fontsize=12)
save(fig,'03_voxel_corte',
     'Un vóxel representa volumen. En este ejemplo, sus lados de 2 mm delimitan 8 mm³. Al fijar un índice del volumen obtenemos una matriz bidimensional; los números de esa matriz son ficticios y sólo ilustran su organización.',
     {'rejilla_3d': [3,3,3], 'voxel_mm': [2,2,2], 'volumen_voxel_mm3': 8, 'corte_sintetico': small.tolist()})

# 04: responsabilidades, no una supuesta dependencia obligatoria entre paquetes.
fig, ax = plt.subplots(figsize=(6.7, 5.0))
ax.set(xlim=(0,10),ylim=(0,8)); ax.axis('off')
items = [('NiBabel','Leer el archivo y\nconservar su geometría'),
         ('NumPy','Guardar matrices y\ncalcular con sus valores'),
         ('SciPy','Aplicar filtros y\nmedir cambios locales'),
         ('Matplotlib','Mostrar imágenes,\ncurvas e histogramas')]
for n,(name,role) in enumerate(items):
    y=6.1-n*1.85
    box(ax,(.25,y),2.65,1.35,name,edge=[NAVY,TEAL,CORAL,AMBER][n],fontsize=14)
    ax.text(3.45,y+.675,role,ha='left',va='center',fontsize=13)
    if n<3: arrow(ax,(1.57,y-.05),(1.57,y-.45))
fig.suptitle('Python reúne herramientas con funciones diferentes')
save(fig,'04_bibliotecas',
     'En esta práctica, NiBabel abre el NIfTI, NumPy representa sus números, SciPy calcula transformaciones y Matplotlib las dibuja. Las flechas muestran un recorrido de trabajo; no implican que toda tarea deba utilizar las cuatro bibliotecas.',
     {'bibliotecas': [x[0] for x in items], 'sin_importar_nilearn': True}, 'diagrama conceptual')

# 05: datos afines reales, con un ejemplo concreto comprobado.
idx=np.array([49,57,46]); mm=nib.affines.apply_affine(AFFINE,idx)
assert np.allclose(mm,[0,-20,20])
fig, ax=plt.subplots(figsize=(6.7,4.0))
ax.set(xlim=(0,10),ylim=(0,5)); ax.axis('off')
box(ax,(.2,2.8),2.3,1.45,'Índices\n(49, 57, 46)',NAVY,fontsize=13)
box(ax,(3.25,2.8),3.4,1.45,'Escala y desplazamiento\nx = 2i − 98\ny = 2j − 134\nz = 2k − 72',TEAL,fontsize=12)
box(ax,(7.4,2.8),2.35,1.45,'Coordenadas\n(0, −20, 20) mm',CORAL,fontsize=12)
arrow(ax,(2.55,3.53),(3.15,3.53)); arrow(ax,(6.72,3.53),(7.32,3.53))
ax.text(5,1.75,'Ejemplo en la rejilla RAS de esta plantilla',ha='center',fontsize=14)
ax.text(5,.85,'i, j, k cuentan posiciones.  x, y, z describen un espacio físico.\nUn índice no es una coordenada en milímetros.',ha='center',va='center',linespacing=1.6)
save(fig,'05_afin_indices_mm',
     'La afín real de la plantilla transforma el índice (49, 57, 46) en (0, −20, 20) mm. En esta rejilla ortogonal, cada eje tiene paso de 2 mm y un desplazamiento distinto. RAS orienta las coordenadas positivas hacia derecha, anterior y superior.',
     {'indice_ijk':idx.tolist(),'coordenadas_mm':mm.tolist(),'affine':AFFINE.tolist()},'plantilla pública')

# 06: mismo multiconjunto de intensidades, distinta organización espacial.
shuffled=np.random.default_rng(SEED).permutation(TOY.ravel()).reshape(TOY.shape)
assert np.array_equal(np.sort(shuffled.ravel()),np.sort(TOY.ravel()))
fig=plt.figure(figsize=(6.7,6.0)); gs=fig.add_gridspec(2,2,height_ratios=[1.05,1])
for n,(arr,title) in enumerate([(TOY,'Organización inicial'),(shuffled,'Mismos valores, otro orden')]):
    ax=fig.add_subplot(gs[0,n]); ax.imshow(arr,cmap='gray',vmin=0,vmax=5,interpolation='nearest')
    ax.set(title=title,xticks=[],yticks=[])
ax=fig.add_subplot(gs[1,:]); counts=np.bincount(TOY.ravel())
ax.bar(np.arange(6),counts,color=TEAL,width=.7)
for n,c in enumerate(counts): ax.text(n,c+.35,str(c),ha='center',va='bottom')
ax.set(title='Un único histograma describe las dos',xlabel='Intensidad',ylabel='Número de píxeles',xticks=range(6),ylim=(0,23))
save(fig,'06_histograma_sin_espacio',
     'Reordenar las 36 intensidades cambia la imagen, pero conserva sus conteos: 20, 6, 6, 2, 1 y 1. El histograma resume la distribución de valores y no conserva su ubicación.',
     {'semilla':SEED,'conteos':counts.tolist(),'matriz_original':TOY.tolist(),'matriz_reordenada':shuffled.tolist()})

# 07: agrupamiento manual comprobable de los mismos números.
fig, axes=plt.subplots(2,1,figsize=(6.7,5.55),sharex=True)
edges1=np.arange(-.5,6,1); edges2=np.array([-.5,1.5,3.5,5.5])
for ax,edges,color,title in zip(axes,[edges1,edges2],[TEAL,NAVY],
                              ['Seis intervalos: un entero por grupo','Tres intervalos: dos enteros por grupo']):
    c,e=np.histogram(TOY,bins=edges)
    ax.bar(e[:-1],c,width=np.diff(e),align='edge',edgecolor='white',color=color)
    for left,right,num in zip(e[:-1],e[1:],c): ax.text((left+right)/2,num+.5,str(num),ha='center')
    ax.set(title=title,ylabel='Píxeles',ylim=(0,30),xticks=range(6))
axes[-1].set_xlabel('Intensidad; los límites quedan entre enteros')
save(fig,'07_intervalos_manuales',
     'Los mismos 36 píxeles se agrupan en seis o en tres intervalos. Los conteos cambian de [20, 6, 6, 2, 1, 1] a [26, 8, 2], pero su suma permanece en 36.',
     {'limites_6':edges1.tolist(),'limites_3':edges2.tolist(),'conteos_6':[20,6,6,2,1,1],'conteos_3':[26,8,2]})

# 08: el cambio de denominador y de escala vertical queda declarado.
fig, axes=plt.subplots(2,1,figsize=(6.7,5.8),sharex=True)
all_counts,edges=np.histogram(CUT,bins=20,range=(0,1))
support_counts,_=np.histogram(CUT[SUPPORT],bins=edges)
for ax,c,color,title in zip(axes,[all_counts,support_counts],[NAVY,TEAL],
                          [f'Todo el corte · {CUT.size} píxeles',f'Sólo soporte > 0,000001 · {SUPPORT.sum()} píxeles']):
    bars=ax.bar(edges[:-1],c,width=np.diff(edges),align='edge',color=color,edgecolor='white')
    if ax is axes[0]: bars[0].set_color(AMBER)
    ax.set(title=title,ylabel='Píxeles',xlim=(0,1))
axes[-1].set_xlabel('Intensidad reescalada')
save(fig,'08_fondo_y_soporte',
     'El fondo cercano a cero domina el histograma completo. La segunda gráfica excluye valores ≤ 0,000001 y permite examinar el resto. Se usan los mismos 20 intervalos, pero escalas verticales distintas: hay que leer sus ejes antes de comparar alturas.',
     {'k':K,'z_mm':float(Z[K]),'bins':20,'rango':[0,1],'poblacion_total':int(CUT.size),'poblacion_soporte':int(SUPPORT.sum()),'excluidos':int((~SUPPORT).sum()),'umbral_soporte':1e-6},'plantilla pública')

# 09: ejemplo de percentiles y ventana sin confundir selección con borrado.
fig,ax=plt.subplots(figsize=(6.7,3.75)); ax.set(xlim=(-5,45),ylim=(-1.8,2.3)); ax.axis('off')
ax.plot([0,40],[.8,.8],color=NAVY,lw=1.5)
for value in [0,10,20,30,40]:
    ax.plot(value,.8,'o',ms=7,color=TEAL)
    ax.text(value,.42,str(value),ha='center')
for value,label in [(10,'P25'),(20,'P50'),(30,'P75')]:
    ax.annotate(label,xy=(value,.85),xytext=(value,1.5),ha='center',color=CORAL,
                arrowprops={'arrowstyle':'-','color':CORAL})
for value,gray in zip([0,10,20,30,40],[0,0,.5,1,1]):
    ax.add_patch(Rectangle((value-3,-.75),6,.65,facecolor=str(gray),edgecolor=NAVY,lw=.8))
    ax.text(value,-1.05,str(value),ha='center')
ax.text(20,2,'Valores ordenados: 0, 10, 20, 30, 40',ha='center',fontsize=14)
ax.text(20,-1.6,'Ventana [P25, P75] = [10, 30] · los datos se conservan',ha='center',fontsize=12)
save(fig,'09_percentiles_recta',
     'Con el método lineal de NumPy, P25=10, P50=20 y P75=30 para estos cinco valores. Una ventana [10, 30] satura los extremos al dibujar: 0 y 10 parecen negros, mientras que 30 y 40 parecen blancos. Ningún valor se borra.',
     {'datos':[0,10,20,30,40],'metodo':'linear','percentiles':[25,50,75],'valores_percentiles':[10,20,30],'ventana':[10,30]})

# 10: la superficie representa intensidad, no altura anatómica.
u=np.linspace(-3,3,121); uu,vv=np.meshgrid(u,u); hill=np.exp(-(uu**2+vv**2)/2)
levels=[.2,.4,.6,.8]; level_colors=[CORAL,AMBER,TEAL,NAVY]
fig=plt.figure(figsize=(6.7,4.35))
ax=fig.add_subplot(121,projection='3d')
ax.plot_surface(uu,vv,hill,cmap=CMAP,rstride=3,cstride=3,linewidth=0,alpha=.95)
ax.set(title='Altura = intensidad',xticks=[-3,0,3],yticks=[-3,0,3],zticks=[0,1])
ax.view_init(26,-50); ax.set_box_aspect((1,1,.65))
ay=fig.add_subplot(122)
ay.imshow(hill,origin='lower',extent=[-3,3,-3,3],cmap='gray',vmin=0,vmax=1)
cs=ay.contour(u,u,hill,levels=levels,colors=level_colors,linewidths=1.7)
ay.clabel(cs,fmt='%.1f',fontsize=12)
ay.set(title='Vista superior y niveles',xlabel='x ficticia',ylabel='y ficticia',xticks=[-3,0,3],yticks=[-3,0,3])
save(fig,'10_colina_y_niveles',
     'La misma función gaussiana se representa como superficie y como mapa visto desde arriba. Cada curva conecta posiciones con igual altura numérica o intensidad. Las coordenadas y la superficie son ficticias.',
     {'funcion':'exp(-(x²+y²)/2)','rango_xy':[-3,3],'niveles':levels,'malla':[121,121]})

# 11: figura cerebral principal, grande, con unidades físicas y leyenda limpia.
fig,ax=plt.subplots(figsize=(6.7,6.7))
brain(ax,title=f'Curvas de nivel en el cerebro · z = {Z[K]:.0f} mm')
lev=[.4,.6,.8]; cols=[CORAL,AMBER,TEAL]
ax.contour(X,Y,CUT,levels=lev,colors=cols,linewidths=1.1)
legend=[Line2D([0],[0],color=c,lw=2,label=f'Intensidad {v:.1f}') for v,c in zip(lev,cols)]
ax.legend(handles=legend,loc='upper center',bbox_to_anchor=(.5,-.12),ncol=3,frameon=False,
          columnspacing=.8,handlelength=1.1,fontsize=12)
save(fig,'11_curvas_cerebro',
     'Las curvas 0,4, 0,6 y 0,8 se superponen al corte axial k=46, situado en z=20 mm. Se calculan con las intensidades de la plantilla y se muestran en coordenadas físicas. Un nivel puede producir varias curvas y no constituye por sí mismo una etiqueta anatómica.',
     {'k':K,'z_mm':float(Z[K]),'niveles':lev,'interpolacion_curva':'contour sobre centros de la rejilla','orientacion':'RAS','ventana':[0,1]},'plantilla pública')

# 12: vecindad cerebral de 7×7; números conocidos e interpolación entre centros.
ii=np.arange(40,47); jj=np.arange(54,61)
patch=DATA[np.ix_(ii,jj,[K])][:,:,0].T
xp=X[ii]; yp=Y[jj]; patch_extent=[xp[0]-1,xp[-1]+1,yp[0]-1,yp[-1]+1]
fig,axes=plt.subplots(1,2,figsize=(6.7,4.6))
for ax in axes:
    ax.imshow(patch,origin='lower',extent=patch_extent,cmap='gray',vmin=0,vmax=1,interpolation='nearest')
    ax.set(xlabel='x (mm)',ylabel='y (mm)',xticks=[xp[0],xp[3],xp[-1]],yticks=[yp[0],yp[3],yp[-1]])
axes[0].set_title('Valores en centros\nrejilla de 2 mm')
for r,y in enumerate(yp):
    for c,x in enumerate(xp):
        axes[0].text(x,y,f'{patch[r,c]:.1f}',ha='center',va='center',fontsize=12,
                     color='white' if patch[r,c]<.55 else NAVY)
axes[1].set_title('Nivel 0,6\nentre centros vecinos')
axes[1].contour(xp,yp,patch,levels=[.6],colors=[CORAL],linewidths=2.3)
axes[1].scatter(*np.meshgrid(xp,yp),s=8,color=AMBER)
save(fig,'12_zoom_curva_interpolada',
     'En esta vecindad cerebral de 7×7, los números se muestran redondeados a un decimal, pero el nivel 0,6 se calcula con los valores completos. Los puntos indican centros de vóxeles separados 2 mm. La línea estima el cruce del nivel entre centros vecinos; no son mediciones nuevas.',
     {'indices_i':ii.tolist(),'indices_j':jj.tolist(),'k':K,'nivel':.6,'redondeo_etiquetas':1,'paso_mm':2,'valores_completos':patch.tolist()},'plantilla pública')

# 13: comparación didáctica de pesos con idéntico soporte de 3×3.
coords=np.arange(-1,2); cx,cy=np.meshgrid(coords,coords)
mean_kernel=np.ones((3,3))/9
gaussian_kernel=np.exp(-(cx*cx+cy*cy)/2); gaussian_kernel/=gaussian_kernel.sum()
fig,axes=plt.subplots(1,2,figsize=(6.7,4.1))
for ax,kernel,title in zip(axes,[mean_kernel,gaussian_kernel],['Media · pesos iguales','Gauss · pesos centrales mayores']):
    ax.imshow(kernel,cmap=CMAP,vmin=0,vmax=.22,interpolation='nearest')
    for (r,c),val in np.ndenumerate(kernel):
        ax.text(c,r,f'{val:.3f}',ha='center',va='center',fontsize=13,
                color='white' if val>.14 else NAVY)
    ax.set(title=title,xticks=[],yticks=[])
    ax.set_xlabel(f'Suma de pesos = {kernel.sum():.0f}')
save(fig,'13_pesos_media_gauss',
     'Ambos núcleos suman uno y conservan una región uniforme. La media da 1/9 a las nueve posiciones; el ejemplo gaussiano favorece el centro. Este gaussiano está truncado a 3×3 y normalizado para ilustrar sus pesos; no es el núcleo completo predeterminado de gaussian_filter.',
     {'media':mean_kernel.tolist(),'gauss_truncado':gaussian_kernel.tolist(),'sigma_ejemplo_px':1,'soporte':[3,3]})

# 14: referencia sintética conocida para mostrar la pérdida de un detalle fino.
phantom=np.zeros((81,101)); phantom[16:66,16:86]=.55; phantom[16:66,48:51]=.95
synthetic_noise=np.random.default_rng(SEED).normal(0,.06,phantom.shape)
noisy_phantom=phantom+synthetic_noise
smooth_phantom=ndimage.gaussian_filter(noisy_phantom,1.6,mode='reflect')
fig=plt.figure(figsize=(6.7,6.15)); gs=fig.add_gridspec(2,3,height_ratios=[1,1])
for n,(arr,title) in enumerate([(phantom,'Referencia ficticia'),(noisy_phantom,'Ruido añadido'),(smooth_phantom,'Gauss σ=1,6 px')]):
    ax=fig.add_subplot(gs[0,n]); ax.imshow(arr,cmap='gray',vmin=0,vmax=1,origin='lower')
    ax.axhline(40,color=CORAL,lw=1,alpha=.8); ax.set(title=title,xticks=[],yticks=[])
ax=fig.add_subplot(gs[1,:])
ax.plot(phantom[40],color=NAVY,lw=2,label='Referencia')
ax.plot(noisy_phantom[40],color=CORAL,alpha=.5,lw=1,label='Con ruido')
ax.plot(smooth_phantom[40],color=TEAL,lw=2,label='Suavizada')
ax.set(xlabel='Columna en la fila marcada',ylabel='Intensidad',ylim=(-.15,1.2),xlim=(30,70))
ax.legend(loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.02),columnspacing=.7,handlelength=1)
save(fig,'14_ruido_y_detalle',
     'Al suavizar este objeto ficticio, disminuyen las fluctuaciones del ruido y también baja y se ensancha la barra brillante de tres píxeles. El perfil corresponde a la línea marcada. La referencia exacta se conoce porque el objeto y el ruido fueron generados para el ejemplo.',
     {'semilla':SEED,'sigma_ruido_intensidad':.06,'sigma_filtro_px':1.6,'modo':'reflect','barra_ancho_px':3,'fila_perfil':40,'forma':list(phantom.shape)})

# 15: un valor brillante no equivale a un gradiente alto.
profiles=[np.full(9,.8),np.linspace(0,1,9),np.r_[np.zeros(4),np.ones(5)]]
names=['Uniforme y brillante','Rampa gradual','Salto abrupto']
fig,axes=plt.subplots(2,3,figsize=(6.7,5.5),sharex='col',sharey='row')
for c,(p,name) in enumerate(zip(profiles,names)):
    axes[0,c].plot(np.arange(9),p,'o-',color=TEAL,ms=4)
    axes[0,c].set(title=name,ylim=(-.1,1.1),xticks=[0,4,8])
    delta=np.diff(p)
    axes[1,c].bar(np.arange(8)+.5,np.abs(delta),color=CORAL,width=.7)
    axes[1,c].set(xlabel='Posición',ylim=(-.05,1.1),xticks=[0,4,8])
axes[0,0].set_ylabel('Intensidad'); axes[1,0].set_ylabel('Cambio absoluto')
save(fig,'15_perfiles_y_cambios',
     'Una fila uniforme puede ser brillante y tener cambio nulo. La rampa cambia 0,125 por paso. El salto concentra un cambio de 1 en una sola transición. Las tres gráficas de cada fila comparten escala para permitir una comparación directa.',
     {'perfiles':[p.tolist() for p in profiles],'cambio':'valor absoluto de diferencias consecutivas','paso':1})

# 16: la misma entrada ruidosa, un filtrado y una sola escala de Sobel.
noise=np.random.default_rng(SEED).normal(0,.06,CUT.shape)
noisy=CUT+noise; smoothed=ndimage.gaussian_filter(noisy,1.2,mode='reflect')
def sobelmag(a):
    return np.hypot(ndimage.sobel(a,axis=1,mode='reflect'),ndimage.sobel(a,axis=0,mode='reflect'))
gradients=[sobelmag(a) for a in [CUT,noisy,smoothed]]
gmax=float(max(g.max() for g in gradients))
fig,axes=plt.subplots(1,3,figsize=(6.7,4.7),sharey=True)
sobel_cmap=LinearSegmentedColormap.from_list('sobel_editorial',['#060E17',NAVY,TEAL,CORAL,AMBER,'#fff7dc'])
for ax,g,title in zip(axes,gradients,['Sobel de referencia','Sobel con ruido','Sobel tras Gauss']):
    artist=brain(ax,g,title,ticks=False,vmin=0,vmax=gmax,cmap=sobel_cmap)
    ax.set(xticks=[-50,0,50],xlabel='x (mm)')
axes[0].set(yticks=[-100,0,50],ylabel='y (mm)')
cbar=fig.colorbar(artist,ax=axes,orientation='horizontal',fraction=.065,pad=.09,aspect=35)
cbar.set_label('Magnitud de Sobel · una escala para los tres paneles')
save(fig,'16_sobel_escala_comun',
     'Sobel se aplica a la plantilla de referencia, a la misma plantilla con ruido y a esa imagen ruidosa suavizada. Los tres mapas comparten límites de color. El suavizado reduce respuestas pequeñas y también puede debilitar bordes. La referencia es la plantilla, no una imagen clínica libre de ruido.',
     {'semilla':SEED,'sigma_ruido_intensidad':.06,'sigma_filtro_px':1.2,'sigma_filtro_mm':2.4,'k':K,'z_mm':float(Z[K]),'modo':'reflect','rango_color':[0,gmax],'formula':'hypot(sobel_axis1, sobel_axis0)'},'plantilla pública')

# 17: una extensión física idéntica en rejillas diferentes.
fig,axes=plt.subplots(1,2,figsize=(6.7,4.5))
for ax,step in zip(axes,[1,3]):
    centers=np.arange(-6,6.01,step); gx,gy=np.meshgrid(centers,centers)
    weights=np.exp(-(gx*gx+gy*gy)/(2*3**2))
    ax.imshow(weights,origin='lower',extent=[-6-step/2,6+step/2,-6-step/2,6+step/2],cmap=CMAP,vmin=0,vmax=1,interpolation='nearest')
    for loc in np.arange(-6-step/2,6+step,step):
        ax.axhline(loc,color='white',lw=.6); ax.axvline(loc,color='white',lw=.6)
    ax.add_patch(Circle((0,0),3,fill=False,edgecolor=CORAL,lw=2,ls='--'))
    pixel_word='píxel' if step==3 else 'píxeles'
    ax.set(title=f'{step} mm por píxel\nσ = {3/step:g} {pixel_word}',xlabel='x (mm)',ylabel='y (mm)',xticks=[-6,0,6],yticks=[-6,0,6],xlim=(-7.5,7.5),ylim=(-7.5,7.5))
fig.suptitle('La misma sigma física de 3 mm en dos rejillas')
save(fig,'17_sigma_fisica',
     'La extensión física σ=3 mm equivale a 3 píxeles en una rejilla de 1 mm y a 1 píxel en una rejilla de 3 mm. El círculo de radio 3 mm marca la misma distancia física. Es un esquema de muestreo de una gaussiana, no una comparación entre adquisiciones clínicas.',
     {'sigma_mm':3,'pasos_mm':[1,3],'sigmas_px':[3,1],'radio_circulo_mm':3})

# 18: los dos formatos combinan valores con información para interpretarlos.
fig,ax=plt.subplots(figsize=(6.7,4.8)); ax.set(xlim=(0,10),ylim=(0,7)); ax.axis('off')
box(ax,(.25,1.7),4.2,4.5,'DICOM\n\nImagen o varios fotogramas\nGeometría y adquisición\nMetadatos del estudio\nPosibles identificadores',NAVY,fontsize=12)
box(ax,(5.55,1.7),4.2,4.5,'NIfTI\n\nMatriz de valores 3D o 4D\nCabecera descriptiva\nTransformación espacial\nPosibles datos acompañantes',TEAL,fontsize=12)
arrow(ax,(4.55,3.9),(5.45,3.9))
ax.text(5,.65,'Cambiar de formato no garantiza anonimato.',ha='center',fontsize=14,color=CORAL)
save(fig,'18_dicom_nifti',
     'DICOM y NIfTI conservan valores junto a información necesaria para interpretarlos. DICOM puede contener una o múltiples imágenes por archivo; NIfTI suele representar un volumen o una serie. La conversión debe conservar la geometría y no sustituye un proceso de desidentificación.',
     {'contenido':'esquema conceptual; sin archivos clínicos'},'diagrama conceptual')

# 19: nueve cortes diferentes con ventana fija y orientación declarada.
fig,axes=plt.subplots(3,3,figsize=(6.7,7.5))
selections=[]
for c,k in enumerate([30,45,60]):
    axes[0,c].imshow(DATA[:,:,k].T,origin='lower',cmap='gray',vmin=0,vmax=1,interpolation='nearest')
    axes[0,c].set_title(f'Axial · z={Z[k]:.0f} mm',fontsize=12)
    selections.append({'plano':'axial','indice':k,'mm':float(Z[k])})
for c,j in enumerate([40,60,80]):
    axes[1,c].imshow(DATA[:,j,:].T,origin='lower',cmap='gray',vmin=0,vmax=1,interpolation='nearest')
    axes[1,c].set_title(f'Coronal · y={Y[j]:.0f} mm',fontsize=12)
    selections.append({'plano':'coronal','indice':j,'mm':float(Y[j])})
for c,i in enumerate([35,49,63]):
    axes[2,c].imshow(DATA[i,:,:].T,origin='lower',cmap='gray',vmin=0,vmax=1,interpolation='nearest')
    axes[2,c].set_title(f'Sagital · x={X[i]:.0f} mm',fontsize=12)
    selections.append({'plano':'sagital','indice':i,'mm':float(X[i])})
for ax in axes.flat: ax.set(xticks=[],yticks=[])
fig.suptitle('Nueve cortes de la misma plantilla · ventana 0 a 1')
save(fig,'19_mosaico_cortes',
     'Cambiar la posición del corte revela regiones distintas de un único volumen. Las nueve vistas mantienen la misma ventana 0–1. En axial y coronal, izquierda y derecha de la imagen corresponden a L y R; en sagital, la horizontal avanza de posterior a anterior. Las coordenadas de los títulos son milímetros del espacio de la plantilla.',
     {'cortes':selections,'ventana':[0,1],'orientacion':'RAS','transposicion':'cada selección se transpone para mostrar sus ejes en la convención descrita'},'plantilla pública')

# 20: grupos sintéticos completamente disjuntos por persona.
groups=[['P01','P02','P03'],['P04'],['P05','P06']]
assert len({p for group in groups for p in group})==sum(map(len,groups))
fig,axes=plt.subplots(1,3,figsize=(6.7,5.8))
for ax,group,title,color in zip(axes,groups,['Entrenamiento','Validación','Prueba'],[TEAL,AMBER,CORAL]):
    ax.set(xlim=(0,1),ylim=(0,4.5)); ax.axis('off'); ax.set_title(title,fontsize=12,color=color)
    for row,p in enumerate(group):
        y=3.4-row*1.25
        box(ax,(.08,y),.84,.95,p+'\n3 cortes',color,fontsize=12)
        for n in range(3):
            ax.add_patch(Rectangle((.19+n*.22,y+.09),.14,.15,facecolor=color,alpha=.75,edgecolor='none'))
fig.suptitle('Seis pacientes ficticios · ninguna persona se repite entre grupos')
fig.supxlabel('Todos los cortes de una persona permanecen en un mismo grupo.',fontsize=12)
save(fig,'20_particion_por_paciente',
     'Los seis identificadores y sus cortes son ficticios. Los tres cortes de cada persona permanecen juntos: P01–P03 en entrenamiento, P04 en validación y P05–P06 en prueba. El esquema ilustra cómo evitar que la misma persona aparezca a ambos lados de la evaluación; no propone tamaños muestrales suficientes para un estudio real.',
     {'grupos':{'entrenamiento':groups[0],'validacion':groups[1],'prueba':groups[2]},'cortes_por_persona':3,'sin_solapamiento':True},'diagrama conceptual')

manifest_path=OUT/'figures_manifest.json'
manifest_path.write_text(json.dumps(MANIFEST,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'figuras':len(MANIFEST),'manifest':str(manifest_path),'nifti_sha256':NIFTI_SHA},ensure_ascii=False),flush=True)
